<?php
$servername = "localhost";
$username   = "id9090371_livin007";
$password   = "livin007";
$dbname     = "id9090371_royalcar";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>