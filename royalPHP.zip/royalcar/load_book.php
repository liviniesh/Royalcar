<?php
error_reporting(0);
include_once("dbconnect.php");
$userid = $_POST['userid'];

$sql = "SELECT * FROM BOOK WHERE USERID = '$userid' AND STATUS = 'not paid'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $response["book"] = array();
    while ($row = $result ->fetch_assoc()){
        $booklist = array();
        $booklist[carid] = $row["CARID"];
        $booklist[carname] = $row["CARNAME"];
        $booklist[rentalperhour] = $row["RENTALPERHOUR"];
        $booklist[hours] = $row["HOURS"];
        $booklist[status] = $row["STATUS"];
        $booklist[companyid] = $row["COMPANYID"];
        $booklist[bookid] = $row["BOOKID"];
        array_push($response["book"], $booklist);
    }
    echo json_encode($response);
}else{
    echo "nodata";
}
?>