<?php
error_reporting(0);
include_once("dbconnect.php");
$userid = $_POST['userid'];
$carid = $_POST['carid'];
    $sqldelete = "DELETE FROM BOOK WHERE USERID = '$userid' AND CARID='$carid'";
    if ($conn->query($sqldelete) === TRUE){
       echo "success";
    }else {
        echo "failed";
    }
?>