<?php
error_reporting(0);
include_once("dbconnect.php");
$carid = $_POST['carid'];
$userid = $_POST['userid'];
$hours = $_POST['hours'];
$rentalperhour = $_POST['rentalperhour'];
$date = $_POST['date'];
$time = $_POST['time'];
$carname = $_POST['carname'];
$companyid = $_POST['companyid'];
$total = $_POST['total'];
$status = "not paid";
    

    $bookid = generateRandomString();
   $sqlinsert = "INSERT INTO BOOK(CARID,USERID,HOURS,RENTALPERHOUR,CARNAME,DATE,TIME,STATUS,COMPANYID,BOOKID,TOTAL) VALUES ('$carid','$userid','$hours','$rentalperhour','$carname','$date','$time','$status','$companyid','$bookid','$total')";
    
    if ($conn->query($sqlinsert) === TRUE) {
        echo "success";
    } else {
        echo "failed";
    }





function generateRandomString($length = 7) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return date('dmY')."-".$randomString;
}

?>