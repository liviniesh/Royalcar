<?php
error_reporting(0);
include_once("dbconnect.php");
$email = $_POST['email'];
$oldpass = $_POST['key'];
$newpassword = $_POST['newpass'];
 $sqlupdate = "UPDATE USER SET PASSWORD = '$newpassword' WHERE EMAIL = '$email' AND PASSWORD = '$oldpass'";
  if ($conn->query($sqlupdate) === TRUE){
        echo "<font color='white'><body bgcolor='black'><h2><br><br>SUCCESS!!  PLEASE LOGIN USING NEW PASSWORD</h2></font>";
  }else{
      echo "<font color='red'><body bgcolor='black'><h2><br><br>FAILED!!!</h2></font>";
}

?>