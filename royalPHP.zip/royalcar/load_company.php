<?php
error_reporting(0);
include_once("dbconnect.php");
$location = $_POST['location'];
if (strcasecmp($location, "All") == 0){
    $sql = "SELECT * FROM COMPANY"; 
}else{
    $sql = "SELECT * FROM COMPANY WHERE LOCATION = '$location'";
}
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $response["company"] = array();
    while ($row = $result ->fetch_assoc()){
        $companylist = array();
        $companylist[companyid] = $row["COMPANYID"];
        $companylist[name] = $row["NAME"];
        $companylist[phone] = $row["PHONE"];
        $companylist[address] = $row["ADDRESS"];
        $companylist[location] = $row["LOCATION"];
        array_push($response["company"], $companylist);
    }
    echo json_encode($response);
}else{
    echo "nodata";
}
?>