<?php
error_reporting(0);
include_once("dbconnect.php");
$userid = $_POST['userid'];

$sql = "SELECT * FROM BOOK WHERE USERID = '$userid'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $response["history"] = array();
    while ($row = $result ->fetch_assoc()){
        $histlist = array();
        $histlist[bookid] = $row["BOOKID"];
        $histlist[total] = $row["TOTAL"];
        $histlist[date] = $row["DATE"];
        array_push($response["history"], $histlist);
    }
    echo json_encode($response);
}else{
    echo "nodata";
}
?>