<?php
error_reporting(0);
include_once("dbconnect.php");
$companyid = $_POST['companyid'];

$sql = "SELECT * FROM CARS WHERE COMPANYID = '$companyid'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $response["car"] = array();
    while ($row = $result ->fetch_assoc()){
        $carlist = array();
        $carlist[carid] = $row["CARID"];
        $carlist[carname] = $row["CARNAME"];
        $carlist[rentalperhour] = $row["RENTALPERHOUR"];
        $carlist[hours] = $row["HOURS"];
        array_push($response["car"], $carlist);
    }
    echo json_encode($response);
}else{
    echo "nodata";
}
?>