<?php
error_reporting(0);
include_once("dbconnect.php");
$carid = $_POST['carid'];
$userid = $_POST['userid'];
$hours = $_POST['hours'];
$rentalperhour = $_POST['rentalperhour'];
$date = $_POST['date'];
$time = $_POST['time'];
$carname = $_POST['carname'];
$status = "not complete";

$sqlsel = "SELECT * FROM CARS WHERE CARID = '$carid'";
$result = $conn->query($sqlsel);
if ($result->num_rows > 0) {
    while ($row = $result ->fetch_assoc()){
        $qavail = $row["HOURS"];
    }
    $bal = $qavail - $hours; 
}

$sqlsel = "SELECT * FROM CARS WHERE CARID = '$carid'";
$result = $conn->query($sqlsel);
if ($result->num_rows > 0) {
    while ($row = $result ->fetch_assoc()){
        $qavail = $row["HOURS"];
    }
    $bal = $qavail - $hours; 
    if ($bal>0){
        $sqlupdate = "UPDATE CARS SET HOURS = '$bal' WHERE CARID = '$carid'";
        $conn->query($sqlupdate);
        $sqlinsert = "INSERT INTO BOOK(CARID,USERID,HOURS,RENTALPERHOUR,DATE,TIME,CARNAME,STATUS) VALUES ('$carid','$userid','$hours','$rentalperhour','$date','$time','$carname','$status')";
        if ($conn->query($sqlinsert) === TRUE){
            echo $bal."success";
        }else {
            echo "failed";
        }
    }
}else{
    echo "failed";
}

?>